import React from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 pt-20 overflow-hidden bg-gray-900">
      <div className="absolute inset-0 geometric-mesh opacity-20"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto flex flex-col-reverse lg:flex-row items-center justify-between gap-12">
        <div className="w-full lg:w-1/2 text-center lg:text-left">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
            <span className="block">Hi, I'm </span>
            <span className="text-blue-400 glow-text">
              Your Name
            </span>
          </h1>
          <h2 className="mt-4 text-xl md:text-2xl text-gray-400 font-light">
            AI & Data Science Developer
          </h2>
          <p className="mt-6 text-lg text-gray-300 max-w-xl mx-auto lg:mx-0">
            Aspiring AI/ML Developer with experience in web development and data-driven projects. 
            Currently pursuing B.Tech in AI & DS in my 3rd year with internship experience at 
            Cognorize, Codesoft, and nxtLogic.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <a 
              href="#projects" 
              className="px-6 py-3 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition-colors font-medium glow"
            >
              View Projects
            </a>
            <a 
              href="#contact" 
              className="px-6 py-3 border-2 border-blue-400 text-blue-400 rounded-lg hover:bg-blue-400/10 transition-colors font-medium"
            >
              Contact Me
            </a>
          </div>
        </div>
        
        <div className="w-full lg:w-1/2 flex justify-center">
          <div className="relative w-64 h-64 md:w-80 md:h-80 floating">
            <div className="absolute inset-0 bg-blue-500/20 rounded-full blur-3xl glow-animate"></div>
            <div className="relative h-full w-full">
              <div className="absolute inset-0 border-4 border-blue-400/50 rounded-3xl transform rotate-45 glow"></div>
              <div className="absolute inset-0 border-4 border-blue-400/30 rounded-3xl transform -rotate-45 glow"></div>
              <div className="absolute inset-8 bg-gradient-to-br from-blue-600/20 to-blue-400/20 rounded-2xl backdrop-blur-sm"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4 transform rotate-45">
                  {[...Array(4)].map((_, i) => (
                    <div
                      key={i}
                      className="w-16 h-16 bg-blue-500/20 rounded-lg backdrop-blur-sm border border-blue-400/30 glow"
                    ></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#about" className="text-blue-400 hover:text-blue-300 transition-colors">
          <ArrowDown className="w-6 h-6" />
        </a>
      </div>
    </section>
  );
};

export default Hero;